
function myfun(){

    var emailcheck=document.getElementById('emailcheck').value;
var pattern=/^([a-zA-Z0-9\.-]+)@([a-zA-Z0-9-]+).([a-z]{2,20})(.[a-z]{2,8})?$/;

    if(pattern.test(emailcheck)){
        document.getElementById('shows').innerHTML = "Valid";
        document.getElementById('shows').style.visibility = "visible";
        document.getElementById('shows').style.color = "green";
    }else{
        document.getElementById('shows').innerHTML = "Invalid";
        document.getElementById('shows').style.visibility = "visible";
        document.getElementById('shows').style.color = "red";
    }
}