var  ram_age=10;
var  syam_age=20;

if(ram_age>syam_age){
    document.write("ram is younger");
}
else if(ram_age=10){
    document.write("ram is younger");
}
else{
    document.write("syam is younger");
}